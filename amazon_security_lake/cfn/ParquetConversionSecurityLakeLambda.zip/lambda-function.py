import os
import boto3
from botocore.config import Config
import json
import uuid
import pyarrow as pa
import pyarrow.parquet as pq
from tempfile import NamedTemporaryFile
from datetime import datetime
import uuid

AWS_REGION = os.getenv('REGION', 'us-west-2')
MAX_LIMIT = 256 * 1024 * 1024

boto_config = Config(
    retries={'max_attempts': 10},
    region_name=AWS_REGION
)


def convert_to_parquet(data, s3):
    
    temp_obj_file = NamedTemporaryFile("wb", delete=False, suffix=".parquet")
    temp_obj_file.close()
    for key, value in data.items():
        data[key] = pa.array(value)
    table = pa.table(data)
    try:
        pq.write_table(table, temp_obj_file.name, use_dictionary=False)
        dst_bucket = os.getenv('DST_BUCKET_NAME')
        account_id = os.getenv('AWS_ACCOUNT_ID')
        prefix = os.getenv('PREFIX')
        folder_name = "eventHour=" + datetime.utcnow().strftime("%Y%m%d%H")
        file_name = str(uuid.uuid1()) + "--" + datetime.utcnow().strftime("%Y%m%d%H%M%S")
        s3.upload_file(temp_obj_file.name, dst_bucket, f"ext/netskope-source/region={AWS_REGION}/accountId={account_id}/{folder_name}/{prefix}_{file_name}.par")
        print("Converted the file to paraquet format and added in the destination bucket.")
        return True
    except Exception as e:
        print(f"Error occurred while generating the parquet file. {e}")
        return False


def merge_data(data, merged_data):
    
    merged_keys = set(merged_data.keys())
    if len(merged_keys) == 0:
        return data
    list_len_of_merged_data = len(list(merged_data.values())[0])
    for data_key in data.keys():
        if data_key not in merged_keys:
            merged_data[data_key] = [None] * list_len_of_merged_data
        else:
            merged_keys.remove(data_key)
        merged_data[data_key].extend(data[data_key])
    list_len_of_data = len(list(data.values())[0])
    for key in merged_keys:
        lst = [None] * list_len_of_data
        merged_data[key].extend(lst)
    return merged_data


def lambda_handler(event, context):

    ssm = boto3.client('ssm')
    try:
        my_parameter = ssm.get_parameter(Name='invoke_counter', WithDecryption=True)
        invoke_counter = my_parameter.get('Parameter', {}).get('Value', '0')
    except Exception:
        updated_param = ssm.put_parameter(Name='invoke_counter', Value='0')
        invoke_counter = "0"

    invoke_counter = int(invoke_counter) + 1
    src_bucket = os.getenv('SRC_BUCKET_NAME')
    s3 = boto3.client('s3', AWS_REGION)
    s3_resource = boto3.resource('s3')
    merged_data = {}
    bucket_file_size = 0
    object_keys = []
    file_count = 0
    source_bucket = s3_resource.Bucket(src_bucket)
    all_objects = source_bucket.objects.all()
    
    if len(list(all_objects)) == 0:
        print("Bucket is Empty")
        return None

    for my_bucket_object in all_objects:
        file_count = file_count + 1
        object_keys.append(my_bucket_object.key)
        bucket_file_size = bucket_file_size + my_bucket_object.size
        if bucket_file_size > MAX_LIMIT or file_count >= 120:
            print(f"Bucket file size: {bucket_file_size} :::: Invoke Counter: {invoke_counter}")
            break
    else:
        if invoke_counter < 5:
            print("Waiting for the file size to hit its limit or the time to hit 5 mins")
            print(f"Bucket file size: {bucket_file_size} :::: Invoke Counter: {invoke_counter}")
            updated_param = ssm.put_parameter(Name='invoke_counter', Value=str(invoke_counter), Overwrite=True)
            return None

    for key in object_keys:
        obj_data = s3.get_object(Bucket=src_bucket, Key=key)
        body = obj_data['Body']
        content = body.read()
        data = json.loads(content)
        merged_data = merge_data(data, merged_data)
    print("Got the merged data...")
    print(f"Converting file into parquet")
    response = convert_to_parquet(merged_data, s3)

    if response is True:
        for key in object_keys:
            s3.delete_object(Bucket=src_bucket, Key=key)
            
    print(f"Exiting Lambda")
    updated_param = ssm.put_parameter(Name='invoke_counter', Value='0', Overwrite=True)